import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import org.hibernate.HibernateException;
import org.hibernate.Metamodel;
import org.hibernate.query.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import javax.persistence.metamodel.EntityType;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

/**
 * Created by nashm on 29/03/2017.
 */
public class Main {
    private static final SessionFactory ourSessionFactory;

    static {
        try {
            Configuration configuration = new Configuration();
            configuration.configure();

            ourSessionFactory = configuration.buildSessionFactory();
        } catch (Throwable ex) {
            throw new ExceptionInInitializerError(ex);
        }
    }

    public static Session getSession() throws HibernateException {
        return ourSessionFactory.openSession();
    }

    public static void main(final String[] args) throws Exception {
        final Session session = getSession();

        String csvFile = "C:\\Users\\Sanea Abid\\Desktop\\GeoLiteCity-Location.csv";
        manageLocations ml = new manageLocations();
        BufferedReader br = null;
        String line = "";
        String cvsSplitBy = ",";
        String[] Line;
        String[] temp;
        try {
            br = new BufferedReader(new FileReader(csvFile));
            int lineNo = 0;
            while ((line = br.readLine()) != null){
                lineNo++;

                if(lineNo >2){
                    temp = line.split(cvsSplitBy);
                    System.out.println(line);
                    if(temp.length <=7){
                        int id =Integer.parseInt(temp[0]);
                        String country = temp[1].replace("\"", "");
                        String region = temp[2].replace("\"", "");
                        String city = temp[3].replace("\"", "");
                        String postalCode = temp[4].replace("\"", "");
                        float lon = Float.parseFloat(temp[5]);
                        float lat = Float.parseFloat(temp[6].replace("\"", ""));

                        ml.addEntry7(id, country, region, city, postalCode, lat, lon);
                    }
                    else {
                        int id =Integer.parseInt(temp[0]);
                        String country = temp[1].replace("\"", "");
                        String region = temp[2].replace("\"", "");
                        String city = temp[3].replace("\"", "");
                        String postalCode = temp[4].replace("\"", "");
                        float lon = Float.parseFloat(temp[5]);
                        float lat = Float.parseFloat(temp[6].replace("\"", ""));

                        int metroCode;
                        if(temp[7].length() > 0)
                            metroCode = Integer.parseInt(temp[7]);
                        else
                            metroCode = 0;

                        int areaCode=0;
                        if(temp.length > 8){
                            if(temp[8].length() > 0)
                                areaCode = Integer.parseInt(temp[8]);
                            else
                                areaCode=0;
                        }


                        ml.addEntry9(id, country, region, city, postalCode, lat, lon, metroCode, areaCode);
                    }
                }

            }



            System.out.println("querying all the managed entities...");
            final Metamodel metamodel = session.getSessionFactory().getMetamodel();
            for (EntityType<?> entityType : metamodel.getEntities()) {
                final String entityName = entityType.getName();
                final Query query = session.createQuery("from " + entityName);
                System.out.println("executing: " + query.getQueryString());
                for (Object o : query.list()) {
                    System.out.println("  " + o);
                }
            }
        } finally {
            session.close();
        }
    }
}
/*public class Main{
public static void main(String[] args) throws FileNotFoundException {
        Scanner scanner = new Scanner(new File("C:\\Users\\Sanea Abid\\Desktop\\GeoLiteCity-Location.csv"));
        scanner.useDelimiter(",");
        while(scanner.hasNext()){
        System.out.print(scanner.next()+"|");
        }
        scanner.close();
        }
        }*/