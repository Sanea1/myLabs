package com;

/**
 * Created by Sanea Abid on 3/17/2017.
 */
public class Box {
    public int X;
    public int Y;
    public Box(int x,int y){
        X=y;
        Y=y;
    }
}
