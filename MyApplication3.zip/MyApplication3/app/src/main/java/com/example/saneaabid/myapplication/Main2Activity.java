package com.example.saneaabid.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;

import com.Box;

import java.util.Random;

public class Main2Activity extends AppCompatActivity {
    ImageButton dice;
    int number;
    Box[] boxes;
    Random numb;
ImageView a;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        boxes=new Box[100];
        boxes[0]=new Box(-170,-147);
        boxes[1]=new Box(-123,-147);
        boxes[2]=new Box(-70,-147);
        boxes[3]=new Box(-25,-147);
        boxes[4]=new Box(25,-147);
        boxes[5]=new Box(75,-147);
        boxes[6]=new Box(120,-147);
        boxes[7]=new Box(175,-147);
        boxes[8]=new Box(220,-147);
        boxes[9]=new Box(272,-147);
        boxes[10]=new Box(272,-200);
        boxes[11]=new Box(220,-200);
        boxes[12]=new Box(175,-200);
        boxes[13]=new Box(120,-200);
        boxes[14]=new Box(75,-200);
        boxes[15]=new Box(25,-200);
        boxes[16]=new Box(-25,-200);
        boxes[17]=new Box(-70,-200);
        boxes[18]=new Box(-123,-200);
        boxes[19]=new Box(-175,-200);
        boxes[20]=new Box(-170,-250);
        boxes[21]=new Box(-170,-250);
        boxes[22]=new Box(-170,-250);
        boxes[23]=new Box(-170,-250);
        boxes[24]=new Box(-170,-250);
        boxes[25]=new Box(-170,-250);
        boxes[26]=new Box(-170,-250);




        final int[][]positions;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        dice = (ImageButton) findViewById(R.id.imageButton2);
        a=(ImageView)findViewById(R.id.imageView4);
        positions= new int[200][2];
       // a.setX(-175);
        //a.setY(-600);

        numb = new Random();
        dice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                number = numb.nextInt(6) + 1;
                if (number == 1) {
                    dice.setImageResource(R.drawable.one);
                } else if (number == 2) {
                    dice.setImageResource(R.drawable.two);
                } else if (number == 3) {
                    dice.setImageResource(R.drawable.three);
                } else if (number == 4) {
                    dice.setImageResource(R.drawable.four);
                } else if (number == 5) {
                    dice.setImageResource(R.drawable.five);
                } else if (number == 6) {
                    dice.setImageResource(R.drawable.six);
                }
            }
        });
    }
}
