/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


//import java.util.LinkedList;
//import java.util.*;



/**
 *
 * @author Sanea Abid
 */
public class Main {
 
 
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
     
      LinkedList1 linkedlist=new LinkedList1();
    
    
    linkedlist.insertTable("Extra Large Table", 12);
    linkedlist.insertTable("Large Table", 6);
    linkedlist.insertTable("Large Table", 6);
    linkedlist.insertTable("Large Table", 6);
    linkedlist.insertTable("Medium Table", 4);
    linkedlist.insertTable("Medium Table", 4);
    linkedlist.insertTable("Medium Table", 4);
    linkedlist.insertTable( "Small Table", 2);
    linkedlist.insertTable( "Small Table", 2);
    linkedlist.insertTable( "Small Table", 2);
    linkedlist.insertTable( "Small Table", 2);
    linkedlist.printList();
    System.out.println("Upon reserving a small table ");
    linkedlist.delete();
    linkedlist.printList();
   // System.out.println("sxjch");
     
    }
    
}
