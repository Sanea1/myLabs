/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Sanea Abid
 */

/*public class customer {
    public String customer_name;
   public  int people_number;
    
}*/
public class customer{
	
	private String cust_name;
        private int cust_Id;
	public customer(int id, String name){
		this.cust_Id = id;
		this.cust_name = name;
		
	}
	
	public int getId(){
		return this.cust_Id;
	}
	
	public String getName(){
		return this.cust_name;
	}
	
	
	
	// update methods
}