/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Sanea Abid
 */
public class Links {
    public String data1;
 public double number;
 public Links next;
 /**/

    /**
     *
     * @param d1
     */

 public Links(String d1,int people){
 data1=d1;
 
 number=people;
 }
 public void printListElements(){
     System.out.println("Available tables are" + data1+number);
     
     
 }
 
}
