/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Sanea Abid
 */
public class LinkedList1 {
     private Links first;
    /*hdsfjvkhdfjv vdf*/
     
    public LinkedList(){
        first=null;
       
       
    }
    public boolean isEmpty(){
        return first==null;
    }
    public void insertTable(String tableType,int d1){
        Links item= new Links(tableType,d1);
        item.next=first;
        
       first=item;
        // first.next=item;
    }
    public Object delete(){
        
        Links temp=first;
        
        first=first.next;
        return temp;//
       
        
        
    }
   
    public void printList(){
        Links current=first;
        System.out.println("List elements are ");
        while(current!=null){
            current.printListElements();
            current=current.next;
        }
    }
     
}
