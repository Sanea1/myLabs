import org.hibernate.*;
import org.hibernate.cfg.Configuration;

import java.util.Iterator;
import java.util.List;

public class Locations {
    private static SessionFactory factory;

   Locations(){
        try{
            factory = new Configuration().configure().buildSessionFactory();
        }catch (Throwable ex) {
            System.err.println("Failed to create sessionFactory object." + ex);
            throw new ExceptionInInitializerError(ex);
        }
    }


    public double Distance(String city1, String city2) //  function to calculate the distance between two cities
    {
        Float[] city1location = Search_Location(city1);
        Float[] city2location = Search_Location(city2);

        double x1 = Math.toRadians((double) city1location[0]);
        double y1 = Math.toRadians((double) city1location[1]);
        double x2 = Math.toRadians((double) city2location[0]);
        double y2 = Math.toRadians((double) city2location[1]);

        double a = Math.pow(Math.sin((x2-x1)/2), 2)
                + Math.cos(x1) * Math.cos(x2) * Math.pow(Math.sin((y2-y1)/2), 2);
        double angle2 = 2 * Math.asin(Math.min(1, Math.sqrt(a))); // great circle distance in radians
        angle2 = Math.toDegrees(angle2); // convert back to degrees
        double distance2 = 60 * angle2;// each degree on a great circle of Earth is 60 nautical miles
        return distance2;
    }

    public Float[] Search_Location (String a) // to find lat n logitude of a city
        {
        Session session = factory.openSession();
        Transaction tx = null;
        Float[] coordinates = new Float[2];
        try{
            tx = session.beginTransaction();
            List cities = session.createQuery("FROM CityData E WHERE E.city='"+a+"'").list();
            Iterator iterator = cities.iterator();
            CityData location = (CityData) iterator.next();
            coordinates[0] = location.getLatitude(); // latitude
            coordinates[1] = location.getLongitude(); //longitude
            tx.commit();
        }catch (HibernateException e) {
            if (tx!=null) tx.rollback();
            e.printStackTrace();
        }finally {
            session.close();
        }
        return coordinates;
    }


}
