import org.hibernate.HibernateException;
import org.hibernate.Metamodel;
import org.hibernate.query.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import javax.persistence.metamodel.EntityType;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;
import java.io.IOException;

public class GeoCityLite{
    private static final SessionFactory ourSessionFactory;

    static {
        try {
            Configuration configuration = new Configuration();
            configuration.configure();

            ourSessionFactory = configuration.buildSessionFactory();
        } catch (Throwable ex) {
            throw new ExceptionInInitializerError(ex);
        }
    }

    public static Session getSession() throws HibernateException {
        return ourSessionFactory.openSession();
    }

  public static void main(final String[] args) throws Exception {
        final Session session = getSession();

        try {

            int option =7;
            do{
                System.out.print("\n\n Choose an option! \n"+
                        "1. Location of a city.\n"+
                        "2. Distance between two cities.\n"+
                        "9. EXIT.\n");
                Scanner scanner = new Scanner(System.in);
                Locations ml = new Locations();
                option = scanner.nextInt();

                if (option==1){
                    System.out.println("Enter City");
                    scanner.nextLine();
                    String city = scanner.nextLine();
                    Float[] coordinates = ml.Search_Location(city);
                    System.out.println("The Location of "+city+":\nLatitude: "+coordinates[0]+"\nLongitude: "+coordinates[1]+"\n");
                }
                else if (option==2)
                {
                    System.out.println("Enter City 1");
                    scanner.nextLine();
                    String city1 = scanner.nextLine();
                    System.out.println("Enter City 2");
                    String city2 = scanner.nextLine();
                    double distance = ml.Distance(city1, city2);
                    System.out.println("The distance between "+city1+"and " +city2+"is : "+distance+"\n");
                }
            }
            while (option!=9);

//            System.out.println("querying all the managed entities...");
//            final Metamodel metamodel = session.getSessionFactory().getMetamodel();
//            for (EntityType<?> entityType : metamodel.getEntities()) {
//                final String entityName = entityType.getName();
//                final Query query = session.createQuery("from " + entityName);
//                System.out.println("executing: " + query.getQueryString());
//                for (Object o : query.list()) {
//                    System.out.println("  " + o);
//                }
//            }
        }
        finally {
            session.close();
        }
    }

}